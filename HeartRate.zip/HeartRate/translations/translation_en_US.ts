<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>Test/behavior.xar:/Say</name>
        <message>
            <source>Your heart rate could not be measured, but I will first record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="obsolete">Your heart rate could not be measured, but I will first record your breakfast preference</translation>
        </message>
    </context>
    <context>
        <name>Test/behavior.xar:/Say goodbye</name>
        <message>
            <source>I will now record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="obsolete">I will now record your breakfast preference</translation>
        </message>
    </context>
    <context>
        <name>Test/behavior.xar:/SayHRfine</name>
        <message>
            <source>You're heartrate is fine.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is fine.</translation>
        </message>
    </context>
    <context>
        <name>Test/behavior.xar:/SayHRhigh</name>
        <message>
            <source>You're heartrate is a little bit too high. I will call a nurse.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is a little bit too high. I will call a nurse.</translation>
        </message>
        <message>
            <source>You're heartrate is abnormal. I will call a nurse.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is abnormal. I will call a nurse.</translation>
        </message>
    </context>
    <context>
        <name>Test/behavior.xar:/SayHRis</name>
        <message>
            <source>Your heartrate is</source>
            <comment>Text</comment>
            <translation type="obsolete">Your heartrate is</translation>
        </message>
    </context>
    <context>
        <name>Test/behavior.xar:/SayHeartRate</name>
        <message>
            <source>Can you touch my head so I can measure your heartrate?</source>
            <comment>Text</comment>
            <translation type="obsolete">Can you touch my head so I can measure your heartrate?</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/Say</name>
        <message>
            <location filename="Timer/behavior.xar" line="0"/>
            <source>Your heart rate could not be measured, but I will first record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="unfinished">Your heart rate could not be measured, but I will first record your breakfast preference</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/Say goodbye</name>
        <message>
            <location filename="Timer/behavior.xar" line="0"/>
            <source>I will now record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="unfinished">I will now record your breakfast preference</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/SayHRfine</name>
        <message>
            <source>You're heartrate is fine.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is fine.</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/SayHRhigh</name>
        <message>
            <source>You're heartrate is a little bit too high. I will call a nurse.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is a little bit too high. I will call a nurse.</translation>
        </message>
        <message>
            <source>You're heartrate is abnormal. I will call a nurse.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is abnormal. I will call a nurse.</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/SayHRis</name>
        <message>
            <location filename="Timer/behavior.xar" line="0"/>
            <source>Your heartrate is</source>
            <comment>Text</comment>
            <translation type="unfinished">Your heartrate is</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/SayHRis (1)</name>
        <message>
            <location filename="Timer/behavior.xar" line="0"/>
            <source>Your heartrate is fine.</source>
            <comment>Text</comment>
            <translation type="unfinished">Your heartrate is fine.</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/SayHRis (2)</name>
        <message>
            <location filename="Timer/behavior.xar" line="0"/>
            <source>Your heartrate is abnormal. I will call a nurse.</source>
            <comment>Text</comment>
            <translation type="unfinished">Your heartrate is abnormal. I will call a nurse.</translation>
        </message>
    </context>
    <context>
        <name>Timer/behavior.xar:/SayHeartRate</name>
        <message>
            <location filename="Timer/behavior.xar" line="0"/>
            <source>Can you touch my head so I can measure your heartrate?</source>
            <comment>Text</comment>
            <translation type="unfinished">Can you touch my head so I can measure your heartrate?</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Touch my head if you want Cola</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my head if you want Cola</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/Say Left</name>
        <message>
            <source>Touch my left hand if you want coffee</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my left hand if you want coffee</translation>
        </message>
        <message>
            <location filename="Touch/behavior.xar" line="0"/>
            <source>Touch this hand if you want coffee</source>
            <comment>Text</comment>
            <translation type="unfinished">Touch this hand if you want coffee</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/Say Right</name>
        <message>
            <source>Touch my right hand if you want tea</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my right hand if you want tea</translation>
        </message>
        <message>
            <location filename="Touch/behavior.xar" line="0"/>
            <source>Touch this hand if you want tea</source>
            <comment>Text</comment>
            <translation type="unfinished">Touch this hand if you want tea</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/SayBread</name>
        <message>
            <location filename="Touch/behavior.xar" line="0"/>
            <source>Coffee it is.</source>
            <comment>Text</comment>
            <translation type="unfinished">Coffee it is.</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/SayCoffee</name>
        <message>
            <source>Coffee it is.</source>
            <comment>Text</comment>
            <translation type="obsolete">Coffee it is.</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/SayCola</name>
        <message>
            <source>Cola it is.</source>
            <comment>Text</comment>
            <translation type="obsolete">Cola it is.</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/SayLeftHand</name>
        <message>
            <source>You chose coffee. If this is wrong touch my head. When it is correct touch my left hand again.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose coffee. If this is wrong touch my head. When it is correct touch my left hand again.</translation>
        </message>
        <message>
            <source>You chose coffee. If this is wrong touch my head. When it is correct touch my left feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose coffee. If this is wrong touch my head. When it is correct touch my left feet.</translation>
        </message>
        <message>
            <source>You chose coffee. If this is wrong touch my head. When it is correct touch my feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose coffee. If this is wrong touch my head. When it is correct touch my feet.</translation>
        </message>
        <message>
            <source>You chose coffee. If this is wrong wait for 5 seconds. When it is correct touch my feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose coffee. If this is wrong wait for 5 seconds. When it is correct touch my feet.</translation>
        </message>
        <message>
            <source>You chose coffee. If this is wrong touch my head. When it is correct touch my one of feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose coffee. If this is wrong touch my head. When it is correct touch my one of feet.</translation>
        </message>
        <message>
            <location filename="Touch/behavior.xar" line="0"/>
            <source>You chose coffee. If this is wrong touch my head. When it is correct touch one of my feet.</source>
            <comment>Text</comment>
            <translation type="unfinished">You chose coffee. If this is wrong touch my head. When it is correct touch one of my feet.</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/SayRightHand</name>
        <message>
            <source>You chose tea. If this is wrong touch my head. When it is correct touch my right hand again.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose tea. If this is wrong touch my head. When it is correct touch my right hand again.</translation>
        </message>
        <message>
            <source>You chose tea. If this is wrong touch my head. When it is correct touch my right teetin.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose tea. If this is wrong touch my head. When it is correct touch my right teetin.</translation>
        </message>
        <message>
            <source>You chose tea. If this is wrong touch my head. When it is correct touch my right feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose tea. If this is wrong touch my head. When it is correct touch my right feet.</translation>
        </message>
        <message>
            <source>You chose tea. If this is wrong touch my head. When it is correct touch my feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose tea. If this is wrong touch my head. When it is correct touch my feet.</translation>
        </message>
        <message>
            <source>You chose tea. If this is wrong wait for 5 seconds. When it is correct touch my feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose tea. If this is wrong wait for 5 seconds. When it is correct touch my feet.</translation>
        </message>
        <message>
            <source>You chose tea. If this is wrong touch my head. When it is correct touch my one of feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose tea. If this is wrong touch my head. When it is correct touch my one of feet.</translation>
        </message>
        <message>
            <location filename="Touch/behavior.xar" line="0"/>
            <source>You chose tea. If this is wrong touch my head. When it is correct touch one of my feet.</source>
            <comment>Text</comment>
            <translation type="unfinished">You chose tea. If this is wrong touch my head. When it is correct touch one of my feet.</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/SayRightHand (1)</name>
        <message>
            <source>You chose cola. If this is wrong touch my head. When it is correct touch my feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose cola. If this is wrong touch my head. When it is correct touch my feet.</translation>
        </message>
        <message>
            <source>You chose cola. If this is wrong wait 10 seconds. When it is correct touch my feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose cola. If this is wrong wait 10 seconds. When it is correct touch my feet.</translation>
        </message>
        <message>
            <source>You chose cola. If this is wrong wait 5 seconds. When it is correct touch my feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose cola. If this is wrong wait 5 seconds. When it is correct touch my feet.</translation>
        </message>
    </context>
    <context>
        <name>Touch/behavior.xar:/SayTea</name>
        <message>
            <location filename="Touch/behavior.xar" line="0"/>
            <source>Tea it is.</source>
            <comment>Text</comment>
            <translation type="unfinished">Tea it is.</translation>
        </message>
    </context>
    <context>
        <name>TouchBreadToast/behavior.xar:/Say Left</name>
        <message>
            <source>Touch my left hand if you want bread</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my left hand if you want bread</translation>
        </message>
        <message>
            <location filename="TouchBreadToast/behavior.xar" line="0"/>
            <source>Touch this hand if you want bread</source>
            <comment>Text</comment>
            <translation type="unfinished">Touch this hand if you want bread</translation>
        </message>
    </context>
    <context>
        <name>TouchBreadToast/behavior.xar:/Say Right</name>
        <message>
            <source>Touch my right hand if you want toast</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my right hand if you want toast</translation>
        </message>
        <message>
            <location filename="TouchBreadToast/behavior.xar" line="0"/>
            <source>Touch this hand if you want toast</source>
            <comment>Text</comment>
            <translation type="unfinished">Touch this hand if you want toast</translation>
        </message>
    </context>
    <context>
        <name>TouchBreadToast/behavior.xar:/SayBread</name>
        <message>
            <location filename="TouchBreadToast/behavior.xar" line="0"/>
            <source>bread it is.</source>
            <comment>Text</comment>
            <translation type="unfinished">bread it is.</translation>
        </message>
    </context>
    <context>
        <name>TouchBreadToast/behavior.xar:/SayLeftHand</name>
        <message>
            <source>You chose bread. If this is wrong touch my head. When it is correct touch my left feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose bread. If this is wrong touch my head. When it is correct touch my left feet.</translation>
        </message>
        <message>
            <source>You chose bread. If this is wrong touch my head. When it is correct touch my one of feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose bread. If this is wrong touch my head. When it is correct touch my one of feet.</translation>
        </message>
        <message>
            <location filename="TouchBreadToast/behavior.xar" line="0"/>
            <source>You chose bread. If this is wrong touch my head. When it is correct touch one of my feet.</source>
            <comment>Text</comment>
            <translation type="unfinished">You chose bread. If this is wrong touch my head. When it is correct touch one of my feet.</translation>
        </message>
    </context>
    <context>
        <name>TouchBreadToast/behavior.xar:/SayRightHand</name>
        <message>
            <source>You chose toast. If this is wrong touch my head. When it is correct touch my right feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose toast. If this is wrong touch my head. When it is correct touch my right feet.</translation>
        </message>
        <message>
            <source>You chose toast. If this is wrong touch my head. When it is correct touch my one of feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose toast. If this is wrong touch my head. When it is correct touch my one of feet.</translation>
        </message>
        <message>
            <location filename="TouchBreadToast/behavior.xar" line="0"/>
            <source>You chose toast. If this is wrong touch my head. When it is correct touch one of my feet.</source>
            <comment>Text</comment>
            <translation type="unfinished">You chose toast. If this is wrong touch my head. When it is correct touch one of my feet.</translation>
        </message>
    </context>
    <context>
        <name>TouchBreadToast/behavior.xar:/SayToast</name>
        <message>
            <location filename="TouchBreadToast/behavior.xar" line="0"/>
            <source>Toast it is.</source>
            <comment>Text</comment>
            <translation type="unfinished">Toast it is.</translation>
        </message>
    </context>
    <context>
        <name>TouchCheeseHam/behavior.xar:/Say Left</name>
        <message>
            <source>Touch my left hand if you want cheese</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my left hand if you want cheese</translation>
        </message>
        <message>
            <source>Touch my this hand if you want cheese</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my this hand if you want cheese</translation>
        </message>
        <message>
            <location filename="TouchCheeseHam/behavior.xar" line="0"/>
            <source>Touch this hand if you want cheese</source>
            <comment>Text</comment>
            <translation type="unfinished">Touch this hand if you want cheese</translation>
        </message>
    </context>
    <context>
        <name>TouchCheeseHam/behavior.xar:/Say Right</name>
        <message>
            <source>Touch my right hand if you want ham</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my right hand if you want ham</translation>
        </message>
        <message>
            <source>Touch my this hand if you want ham</source>
            <comment>Text</comment>
            <translation type="obsolete">Touch my this hand if you want ham</translation>
        </message>
        <message>
            <location filename="TouchCheeseHam/behavior.xar" line="0"/>
            <source>Touch this hand if you want ham</source>
            <comment>Text</comment>
            <translation type="unfinished">Touch this hand if you want ham</translation>
        </message>
    </context>
    <context>
        <name>TouchCheeseHam/behavior.xar:/SayCheese</name>
        <message>
            <source>bread it is.</source>
            <comment>Text</comment>
            <translation type="obsolete">bread it is.</translation>
        </message>
        <message>
            <location filename="TouchCheeseHam/behavior.xar" line="0"/>
            <source>Cheese it is.</source>
            <comment>Text</comment>
            <translation type="unfinished">Cheese it is.</translation>
        </message>
    </context>
    <context>
        <name>TouchCheeseHam/behavior.xar:/SayHam</name>
        <message>
            <source>Toast it is.</source>
            <comment>Text</comment>
            <translation type="obsolete">Toast it is.</translation>
        </message>
        <message>
            <location filename="TouchCheeseHam/behavior.xar" line="0"/>
            <source>Ham it is.</source>
            <comment>Text</comment>
            <translation type="unfinished">Ham it is.</translation>
        </message>
    </context>
    <context>
        <name>TouchCheeseHam/behavior.xar:/SayLeftHand</name>
        <message>
            <source>You chose cheese. If this is wrong touch my head. When it is correct touch my left feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose cheese. If this is wrong touch my head. When it is correct touch my left feet.</translation>
        </message>
        <message>
            <source>You chose cheese. If this is wrong touch my head. When it is correct touch my one of feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose cheese. If this is wrong touch my head. When it is correct touch my one of feet.</translation>
        </message>
        <message>
            <location filename="TouchCheeseHam/behavior.xar" line="0"/>
            <source>You chose cheese. If this is wrong touch my head. When it is correct touch one of my feet.</source>
            <comment>Text</comment>
            <translation type="unfinished">You chose cheese. If this is wrong touch my head. When it is correct touch one of my feet.</translation>
        </message>
    </context>
    <context>
        <name>TouchCheeseHam/behavior.xar:/SayRightHand</name>
        <message>
            <source>You chose ham. If this is wrong touch my head. When it is correct touch my right feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose ham. If this is wrong touch my head. When it is correct touch my right feet.</translation>
        </message>
        <message>
            <source>You chose ham. If this is wrong touch my head. When it is correct touch my one of feet.</source>
            <comment>Text</comment>
            <translation type="obsolete">You chose ham. If this is wrong touch my head. When it is correct touch my one of feet.</translation>
        </message>
        <message>
            <location filename="TouchCheeseHam/behavior.xar" line="0"/>
            <source>You chose ham. If this is wrong touch my head. When it is correct touch one of my feet.</source>
            <comment>Text</comment>
            <translation type="unfinished">You chose ham. If this is wrong touch my head. When it is correct touch one of my feet.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Oke, I am done here. Have a nice day</source>
            <comment>Text</comment>
            <translation type="obsolete">Oke, I am done here. Have a nice day</translation>
        </message>
        <message>
            <source>You're heartrate is fine.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is fine.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>You're heartrate is fine.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is fine.</translation>
        </message>
        <message>
            <source>You're heartrate is a little bit too high. I will call a nurse.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is a little bit too high. I will call a nurse.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>output_HR</source>
            <comment>Text</comment>
            <translation type="obsolete">output_HR</translation>
        </message>
        <message>
            <source>output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">output_RandomValue</translation>
        </message>
        <message>
            <source>Your heartrate is</source>
            <comment>Text</comment>
            <translation type="obsolete">Your heartrate is</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Your heartrate could not be measured</source>
            <comment>Text</comment>
            <translation type="obsolete">Your heartrate could not be measured</translation>
        </message>
        <message>
            <source>Your heartrate could not be measured, but I will first record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="obsolete">Your heartrate could not be measured, but I will first record your breakfast preference</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Your heart rate could not be measured, but I will first record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="unfinished">Your heart rate could not be measured, but I will first record your breakfast preference</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say HR</name>
        <message>
            <source>You're heartrate is output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is output_RandomValue</translation>
        </message>
        <message>
            <source>You're heartrate is $output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is $output_RandomValue</translation>
        </message>
        <message>
            <source>You're heartrate is ~output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is ~output_RandomValue</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say HR (1)</name>
        <message>
            <source>You're heartrate is $output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is $output_RandomValue</translation>
        </message>
        <message>
            <source>You're heartrate is ~output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is ~output_RandomValue</translation>
        </message>
        <message>
            <source>(e:output_RandomValue) You're heartrate is ~output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">(e:output_RandomValue) You're heartrate is ~output_RandomValue</translation>
        </message>
        <message>
            <source>You're heartrate is %s %(output_RandomValue)</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is %s %(output_RandomValue)</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say HeartRate</name>
        <message>
            <source>You're heartrate is output_RandomValue</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is output_RandomValue</translation>
        </message>
        <message>
            <source>You're heartrate is </source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is </translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say goodbye</name>
        <message>
            <source>Oke, I am done here. Have a nice day</source>
            <comment>Text</comment>
            <translation type="obsolete">Oke, I am done here. Have a nice day</translation>
        </message>
        <message>
            <source>Thank you, I am done here. Have a nice day</source>
            <comment>Text</comment>
            <translation type="obsolete">Thank you, I am done here. Have a nice day</translation>
        </message>
        <message>
            <source>Thank you, I will now record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="obsolete">Thank you, I will now record your breakfast preference</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I will now record your breakfast preference</source>
            <comment>Text</comment>
            <translation type="unfinished">I will now record your breakfast preference</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SayHRfine</name>
        <message>
            <source>You're heartrate is fine.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is fine.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SayHRhigh</name>
        <message>
            <source>You're heartrate is a little bit too high. I will call a nurse.</source>
            <comment>Text</comment>
            <translation type="obsolete">You're heartrate is a little bit too high. I will call a nurse.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SayHRis</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Your heartrate is</source>
            <comment>Text</comment>
            <translation type="unfinished">Your heartrate is</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SayHeartRate</name>
        <message>
            <source>Can you give your hand so I can measure your heart rate?</source>
            <comment>Text</comment>
            <translation type="obsolete">Can you give your hand so I can measure your heart rate?</translation>
        </message>
        <message>
            <source>Can you give your head so I can measure your heart rate?</source>
            <comment>Text</comment>
            <translation type="obsolete">Can you give your head so I can measure your heart rate?</translation>
        </message>
        <message>
            <source>Can you touch my head so I can measure your heart rate?</source>
            <comment>Text</comment>
            <translation type="obsolete">Can you touch my head so I can measure your heart rate?</translation>
        </message>
        <message>
            <source>Can you touch my head so I can measure your heart rate?S</source>
            <comment>Text</comment>
            <translation type="obsolete">Can you touch my head so I can measure your heart rate?S</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Can you touch my head so I can measure your heartrate?</source>
            <comment>Text</comment>
            <translation type="unfinished">Can you touch my head so I can measure your heartrate?</translation>
        </message>
        <message>
            <source>Can you touch my forehead so I can measure your heartrate?</source>
            <comment>Text</comment>
            <translation type="obsolete">Can you touch my forehead so I can measure your heartrate?</translation>
        </message>
    </context>
</TS>
